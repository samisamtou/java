public class Journalier extends Employe {
    private int duree;
    private int forfait;

    public Journalier() {
        this.duree = 0;
        this.forfait = 0;
    }

    public int getDuree() {
        return duree;
    }

    public void setDuree(int duree) {
        this.duree = duree;
    }

    public int getForfait() {
        return forfait;
    }

    public void setForfait(int forfait) {
        this.forfait = forfait;
    }

    public Journalier(int id, String nom, int duree, int forfait) {
        super(id, nom);
        this.duree = duree;
        this.forfait = forfait;
    }

    public void affiche(){

    }
}
