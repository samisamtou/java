public class Employe {
    protected int id;
    private  static int idCount;

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getId() {
        return id;
    }

    protected String nom;

    public Employe() {
        this.id = idCount++;
        this.nom = "nom";
    }

    public Employe(int id, String nom) {
        this.id = idCount++;
        this.nom = nom;
    }


    public void affiche(){

    }

    public boolean isEmbauche(){
        return true;
    }

    public boolean isJournalier(){
        return true;
    }
    
    
}