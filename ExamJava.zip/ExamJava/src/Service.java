public class Service {
    private int id;
    private  static int idCount;
    private String libelle;

    public Service() {

        this.id = idCount++;
        this.libelle = "";
    }

    public Service(String libelle) {
        this.id = idCount++;
        this.libelle = libelle;
    }

    public void affiche(){
        System.out.println(this.id+"\t"+this.libelle);

    }

    public int getId() {
        return id;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public boolean compare(int id){
        return true;
    }

    public boolean compare(String libelle){
        return true;
    }
}
