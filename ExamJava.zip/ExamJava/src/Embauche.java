public class Embauche extends Employe {

    private double salaire;
    private String dateEmbauche;

    public int getIdService() {
        return idService;
    }

    public void setIdService(int idService) {
        this.idService = idService;
    }

    private int idService;

    public Embauche() {
        super();
        this.salaire = 0;
        this.dateEmbauche = "";
    }

    public double getSalaire() {
        return salaire;
    }

    public void setSalaire(double salaire) {
        this.salaire = salaire;
    }

    public String getDateEmbauche() {
        return dateEmbauche;
    }

    public void setDateEmbauche(String dateEmbauche) {
        this.dateEmbauche = dateEmbauche;
    }

    public Embauche(int id, String nom, double salaire, String dateEmbauche) {
        super(id, nom);
        this.salaire = salaire;
        this.dateEmbauche = dateEmbauche;
    }

    public void affiche(){

    }


}
