import java.util.ArrayList;
import java.util.Scanner;

public class Launch {
    public static void main(String[] args) {
        ArrayList<Service> services = new ArrayList<Service>();
        ArrayList<Employe> employes = new ArrayList<Employe>();
        System.out.println("Examen Java Intrface");
        System.out.println("---------------------------");
        System.out.println("Appuyer sur ");
        System.out.println("1- Ajouter service");
        System.out.println("2- Lister services");
        System.out.println("3- Ajouter employé");
        System.out.println("4- Lister les Journaliers");
        System.out.println("5- Lister les embauchés d'un service");
        System.out.println("6- Quiter");
        System.out.println("Votre choix");

        Scanner sc = new Scanner(System.in);
        int choix = sc.nextInt();

        while (choix<0 && choix>7 ){
            System.out.println("Mauvaise valeur ressayer");
            choix = sc.nextInt();
        };

        switch (choix){
            case 1:
                System.out.println("Ajoute service");
                System.out.println("Libelle service");
                Service service = new Service();

                service.setLibelle(sc.next());
                services.add(service);
                break;

            case 2:
                System.out.println("Liste services");
                System.out.println("id \t libelle");
                for (int i = 0; i < services.size(); i++){
                    Service se = new Service();
                    se = services.get(i);
                    se.affiche();
                }
                break;

            case 3:
                System.out.println("Ajoute employe");
                System.out.println("Appuyer sur ");
                System.out.println("1- Ajouter Journalier");
                System.out.println("2- ajouter embauche");

                int choix2 = sc.nextInt();
                while (choix<0 && choix>3 ){
                    System.out.println("Mauvaise valeur ressayer");
                    choix = sc.nextInt();
                };

                switch (choix2){
                    case 1:
                        System.out.println("1- Ajouter Journalier");





                        Journalier j = new Journalier();
                        System.out.println("nom");
                        j.setNom(sc.next());
                        System.out.println("duree");
                        j.setDuree(sc.nextInt());
                        System.out.println("forfait");
                        j.setForfait(sc.nextInt());
                        employes.add(j);
                        break;
                    case 2:
                        System.out.println("2- ajouter embauche");
                        Embauche e = new Embauche();
                        System.out.println("nom");
                        e.setNom(sc.next());
                        System.out.println("salaire");
                        e.setSalaire(sc.nextInt());
                        System.out.println("date embauche");
                        e.setDateEmbauche(sc.next());
                        System.out.println("service");
                        e.setIdService(sc.nextInt());
                        break;
                }

        }



    }
}
