public class Boussier extends Etudiant {
    String type;
    double mnt;

    public Boussier(String matricule, String nom, String prenom, String dateNaisss, String type, double mnt) {
        super(matricule, nom, prenom, dateNaisss);
        this.type = type;
        this.mnt = mnt;
    }

    public Boussier() {
        super();
        this.type = "";
        this.mnt = 0;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getMnt() {
        return mnt;
    }

    public void setMnt(double mnt) {
        this.mnt = mnt;
    }

    public void affiche(){
        super.affiche();
        System.out.println(this.type+"\t"+this.mnt);
    }
}
