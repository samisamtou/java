public class Etudiant {
    String matricule,nom,prenom,dateNaisss;

    public Etudiant(String matricule, String nom, String prenom, String dateNaisss) {
        this.matricule = matricule;
        this.nom = nom;
        this.prenom = prenom;
        this.dateNaisss = dateNaisss;
    }

    public Etudiant() {
        this.matricule = "";
        this.nom = "";
        this.prenom = "";
        this.dateNaisss = "";
    }

    public String getMatricule() {
        return matricule;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getDateNaisss() {
        return dateNaisss;
    }

    public void setDateNaisss(String dateNaisss) {
        this.dateNaisss = dateNaisss;
    }

    public void affiche(){
        System.out.print(this.matricule+"\t"+this.nom+"\t"+this.prenom+"\t"+this.dateNaisss);
    }
}
