public class NonBourssier extends Etudiant {
    int aide;
    String adresse;

    public NonBourssier(String matricule, String nom, String prenom, String dateNaisss, String adresse) {
        super(matricule, nom, prenom, dateNaisss);
        this.aide = 60000;
        this.adresse = adresse;
    }

    public NonBourssier() {
        super();
        this.aide = 60000;
        this.adresse = "";
    }

    public int getAide() {
        return aide;
    }

    public void setAide(int aide) {
        this.aide = aide;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }
    public void affiche(){
        super.affiche();
        System.out.println(this.aide+"\t"+this.adresse);
    }
}
