public class Loge extends Boussier {
    String chambre;

    public Loge(String matricule, String nom, String prenom, String dateNaisss, String type, double mnt, String chambre) {
        super(matricule, nom, prenom, dateNaisss, type, mnt);
        this.chambre = chambre;
    }

    public Loge() {
        super();
        this.chambre = "";
    }

    public String getChambre() {
        return chambre;
    }

    public void setChambre(String chambre) {
        this.chambre = chambre;
    }

    public void affiche(){
        super.affiche();
        System.out.println(this.chambre+"\t");
    }
}
