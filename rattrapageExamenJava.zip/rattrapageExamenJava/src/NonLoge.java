public class NonLoge extends Boussier {
    String adresse;

    public NonLoge(String matricule, String nom, String prenom, String dateNaisss, String type, double mnt, String adresse) {
        super(matricule, nom, prenom, dateNaisss, type, mnt);
        this.adresse = adresse;
    }

    public NonLoge() {
        super();
        this.adresse = "";
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public void affiche(){
        super.affiche();
        System.out.println("\t"+this.adresse);
    }
}
