import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        ArrayList<NonBourssier> etudiantNonBoursier = new ArrayList<NonBourssier>();
        ArrayList<Loge> etudiantBoursierLoge = new ArrayList<Loge>();
        ArrayList<NonLoge> etudiantBoursierNonLoge = new ArrayList<NonLoge>();
        System.out.println("Menu Administation");
        System.out.println("1- pour Enregistrer etudiant");
        System.out.println("2- pour Afiicher les bourssiers");
        System.out.println("3- pour Afiicher les non bourssiers");
        System.out.println("Votre choix");
        Scanner sc = new Scanner(System.in);
        int choix = sc.nextInt();
        char close = 'o';
        while (choix<=0 || choix>3){
            System.out.println("vous devez choisir un nombre entre 1 et 5 /n merci de ressayer");
            choix = sc.nextInt();
        }

        while (close!='n'){
            switch (choix){
                case 1:
                    System.out.println("Enregistrer etudiant");
                    System.out.print("matricule etudiant:");
                    String matricule = sc.next();
                    System.out.print("nom etudiant:");
                    String nom = sc.next();
                    System.out.print("prenom etudiant:");
                    String prenom = sc.next();
                    System.out.print("Date de naissainca etudiant:");
                    String dateNaissance = sc.next();
                    System.out.print("l'etudiant est il bourssier o/n");
                    String etB = sc.next();
                    while (!etB.equals("o") && !etB.equals("n")){
                        System.out.print("choix attendu o/n");
                        etB = sc.next();
                    }
                    if (etB.equals("o")){
                        System.out.print("type de bourse /n 1- pour entire /n 2- pour demi");
                        int bourse = sc.nextInt();
                        while (bourse!=1 && bourse!=2){
                            System.out.print("choix attendu 1 ou 2");
                            bourse = sc.nextInt();
                        }
                        String typeBourse;
                        int montant;
                        if (bourse==1){
                            typeBourse = "entiere";
                            montant = 180000;
                        }else{
                            typeBourse = "demi";
                            montant = 80000;
                        }
                        System.out.print("l'etudiant est il loge o/n");
                        String etL = sc.next();
                        while (!etL.equals("o") && !etL.equals("n")){
                            System.out.print("choix attendu o/n");
                            etL = sc.next();
                        }
                        if (etL.equals("o")){
                            System.out.print(" chambre etudiant:");
                            String chambre = sc.next();
                            Loge etLoge = new Loge(matricule,nom,prenom,dateNaissance,typeBourse,montant,chambre);
                            etudiantBoursierLoge.add(etLoge);
                        }else {
                            System.out.print(" addresse etudiant:");
                            String addr = sc.next();
                            NonLoge etNlog = new NonLoge(matricule,nom,prenom,dateNaissance,typeBourse,montant,addr);
                            etudiantBoursierNonLoge.add(etNlog);
                        }
                    }else{
                        System.out.print(" addresse etudiant:");
                        String addr2 = sc.next();
                        NonBourssier etudiant = new NonBourssier(matricule,nom,prenom,dateNaissance,addr2);
                        etudiantNonBoursier.add(etudiant);
                    }
                    break;
                case 2:
                    System.out.println("affichage etudiants bourssier loge");
                    for (int i=0; i<etudiantBoursierLoge.size();i++){
                        Loge aff = new Loge();
                        aff =etudiantBoursierLoge.get(i);
                        aff.affiche();
                    }
                    System.out.println("affichage etudiants bourssier non loge");
                    for (int i=0; i<etudiantBoursierNonLoge.size();i++){
                        NonLoge aff = new NonLoge();
                        aff =etudiantBoursierNonLoge.get(i);
                        aff.affiche();
                    }
                    break;
                default:
                    System.out.println("affichage etudiants non bourssier");
                    for (int i=0; i<etudiantNonBoursier.size();i++){
                        NonBourssier aff = new NonBourssier();
                        aff =etudiantNonBoursier.get(i);
                        aff.affiche();
                    }
                    break;
            }
            System.out.println("voulez vous conitinuer o/n");
            close = sc.next().charAt(0);
            if (close=='o'){
                System.out.println("Menu Administation");
                System.out.println("1- pour Enregistrer etudiant");
                System.out.println("2- pour Afiicher les bourssiers");
                System.out.println("3- pour Afiicher les non bourssiers");
                System.out.println("Votre choix");
                choix = sc.nextInt();
            }
        }

    }



}
