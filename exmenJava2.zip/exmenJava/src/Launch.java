import java.util.Scanner;

public class Launch {
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        System.out.println("Examen Java Intrface");
        System.out.println("---------------------------");
        System.out.println("Appuyer sur ");
        System.out.println("1- Ajouter service");
        System.out.println("2- Lister services");
        System.out.println("3- Ajouter employé");
        System.out.println("4- Lister les Journaliers");
        System.out.println("5- Lister les embauchés d'un service");
        System.out.println("6- Quiter");
        System.out.println("Votre choix");

        Scanner sc = new Scanner(System.in);
        int choix = sc.nextInt();

        while (choix<0 && choix>7 ){
            System.out.println("Mauvaise valeur ressayer");
            choix = sc.nextInt();
        };

        switch (choix){
            case 1:

                break;
        }



    }
}
