public class Embauche extends Employe {

    private double salaire;
    private String dateEmbauche;

    public Embauche() {
        super();
        this.salaire = 0;
        this.dateEmbauche = "";
    }

    public Embauche(int id, String nom, double salaire, String dateEmbauche) {
        super(id, nom);
        this.salaire = salaire;
        this.dateEmbauche = dateEmbauche;
    }

    public void affiche(){

    }


}
