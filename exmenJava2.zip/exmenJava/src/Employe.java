public class Employe {
    protected int id;
    protected String nom;

    public Employe() {
        this.id = Integer.parseInt(null);
        this.nom = "nom";
    }

    public Employe(int id, String nom) {
        this.id = id;
        this.nom = nom;
    }

    public void affiche(){

    }

    public boolean isEmbauche(){
        return true;
    }

    public boolean isJournalier(){
        return true;
    }
    
    
}