public class Journalier extends Employe {
    private int duree;
    private int forfait;

    public Journalier() {
        this.duree = 0;
        this.forfait = 0;
    }

    public Journalier(int id, String nom, int duree, int forfait) {
        super(id, nom);
        this.duree = duree;
        this.forfait = forfait;
    }

    public void affiche(){

    }
}
