public class Service {
    private int id;
    private String libelle;

    public Service() {
        this.id = Integer.parseInt(null);
        this.libelle = "";
    }

    public Service(int id, String libelle) {
        this.id = id;
        this.libelle = libelle;
    }

    public void affiche(){

    }

    public boolean compare(int id){
        return true;
    }

    public boolean compare(String libelle){
        return true;
    }
}
